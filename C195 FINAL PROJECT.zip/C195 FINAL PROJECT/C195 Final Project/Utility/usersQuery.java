package Utility;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Utility.JDBC;

public abstract class usersQuery {

    public static int insert(String username, String password, int userId) throws SQLException {
        String sql = "INSERT INTO client_schedule.users (User_ID, User_Name, Password) VALUES (?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, userId);
        ps.setString(2, username);
        ps.setString(3, password);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int update(String username, String password, int userId) throws SQLException {
        String sql = "UPDATE client_schedule.users SET User_Name = ?, Password = ? WHERE User_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(3, userId);
        ps.setString(1, username);
        ps.setString(2, password);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int delete(int userId) throws SQLException {
        String sql = "DELETE FROM client_schedule.users WHERE User_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, userId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static void select() throws SQLException {
        String sql = "SELECT * FROM client_schedule.users";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int userId = rs.getInt("User_ID");
            String username = rs.getString("User_Name");
            String password = rs.getString("Password");
            System.out.print(userId + " | ");
            System.out.print(username + " | ");
            System.out.print(password + "\n");
        }
    }

    public static void select(int userId) throws SQLException {
        String sql = "SELECT * FROM client_schedule.users WHERE User_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int userIdFK = rs.getInt("User_ID");
            String username = rs.getString("User_Name");
            String password = rs.getString("Password");
            System.out.print(userIdFK + " | ");
            System.out.print(username + " | ");
            System.out.print(password + "\n");
        }
    }
}
