package Utility;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class fldQuery {

    public static int insert(int divisionId, String division, int countryId) throws SQLException {
        String sql = "INSERT INTO client_schedule.first_level_divisions (Division_ID, Division, Country_ID) VALUES (?, ?, ?)";
        PreparedStatement ps = Utility.JDBC.connection.prepareStatement(sql);
        ps.setInt(1, divisionId);
        ps.setString(2, division);
        ps.setInt(3, countryId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int update(int divisionId, String division, int countryId) throws SQLException {
        String sql = "UPDATE client_schedule.first_level_divisions SET Division = ?, Country_Id = ? WHERE Division_ID = ?";
        PreparedStatement ps = Utility.JDBC.connection.prepareStatement(sql);
        ps.setInt(3, divisionId);
        ps.setString(1, division);
        ps.setInt(2, countryId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int delete(int divisionId) throws SQLException {
        String sql = "DELETE FROM client_schedule.first_level_divisions WHERE Division_ID = ?";
        PreparedStatement ps = Utility.JDBC.connection.prepareStatement(sql);
        ps.setInt(1, divisionId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static void select() throws SQLException {
        String sql = "SELECT * FROM client_schedule.first_level_divisions";
        PreparedStatement ps = Utility.JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int divisionId = rs.getInt("Division_ID");
            String division = rs.getString("Division");
            int countryId = rs.getInt("Country_ID");
            System.out.print(divisionId + " | ");
            System.out.print(division + " | ");
            System.out.print(countryId + "\n");
        }
    }

    public static void select(int divisionId) throws SQLException {
        String sql = "SELECT * FROM client_schedule.users WHERE User_ID = ?";
        PreparedStatement ps = Utility.JDBC.connection.prepareStatement(sql);
        ps.setInt(1, divisionId);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int divisionIdFK = rs.getInt("Division_ID");
            String division = rs.getString("Division");
            int countryId = rs.getInt("Country_ID");
            System.out.print(divisionIdFK + " | ");
            System.out.print(division + " | ");
            System.out.print(countryId + "\n");
        }
    }
}
