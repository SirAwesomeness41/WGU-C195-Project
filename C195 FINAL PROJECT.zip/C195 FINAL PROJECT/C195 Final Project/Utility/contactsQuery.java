package Utility;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class contactsQuery {

    public static int insert(int contactId, String contactName, String email) throws SQLException {
        String sql = "INSERT INTO client_schedule.contacts (Contact_ID, Contact_Name, Email) VALUES (?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, contactId);
        ps.setString(2, contactName);
        ps.setString(3, email);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int update(int contactId, String contactName, String email) throws SQLException {
        String sql = "UPDATE client_schedule.contacts SET Contact_Name = ?, Email = ? WHERE Contact_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(3, contactId);
        ps.setString(1, contactName);
        ps.setString(2, email);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int delete(int contactId) throws SQLException {
        String sql = "DELETE FROM client_schedule.contacts WHERE Contact_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, contactId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static void select() throws SQLException {
        String sql = "SELECT * FROM client_schedule.contacts";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int contactId = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            String email = rs.getString("Email");
            System.out.print(contactId + " | ");
            System.out.print(contactName + " | ");
            System.out.print(email + "\n");
        }
    }

    public static void select(int contactId) throws SQLException {
        String sql = "SELECT * FROM client_schedule.users WHERE User_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, contactId);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int contactIdFK = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            String email = rs.getString("Email");
            System.out.print(contactIdFK + " | ");
            System.out.print(contactName + " | ");
            System.out.print(email + "\n");
        }
    }
}
