package Utility;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class countryQuery {

    public static int insert(String country, int countryId) throws SQLException {
        String sql = "INSERT INTO client_schedule.countries (Country, Country_ID) VALUES (?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, country);
        ps.setInt(2, countryId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int update(String country, int countryId) throws SQLException {
        String sql = "UPDATE client_schedule.countries SET Country = ? WHERE Country_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(2, countryId);
        ps.setString(1, country);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static int delete(int countryId) throws SQLException {
        String sql = "DELETE FROM client_schedule.countries WHERE Division_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, countryId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static void select() throws SQLException {
        String sql = "SELECT * FROM client_schedule.countries";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            String country = rs.getString("Country");
            int countryId = rs.getInt("Country_ID");
            System.out.print(country + " | ");
            System.out.print(countryId + "\n");
        }
    }

    public static void select(int countryId) throws SQLException {
        String sql = "SELECT * FROM client_schedule.users WHERE User_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, countryId);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int countryIdFK = rs.getInt("Country_ID");
            String country = rs.getString("Country");
            System.out.print(country + " | ");
            System.out.print(countryIdFK + "\n");
        }
    }
}
