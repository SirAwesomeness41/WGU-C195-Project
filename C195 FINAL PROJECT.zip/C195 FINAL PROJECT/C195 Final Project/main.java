import DAO.DBConnection;
import Utility.usersQuery;
import Utility.JDBC;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static javafx.application.Application.launch;

public class main extends Application {
    public static void main(String[] args) throws SQLException {
        DBConnection.openConnection();
        launch(args);
        DBConnection.closeConnection();
    }

    @Override
    public void start(Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader();
            Parent parent = loader.load(getClass().getResource("View/loginScreen.fxml"));
            Scene scene = new Scene(parent);
            stage.setTitle("Log In");
            stage.setScene(scene);
            stage.show();
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }
}