package Model;

public class Customers {

    private String divisionName;
    private int customerID;
    private String customerName;
    private String customerAddress;
    private String customerPostalCode;
    private String customerPhoneNumber;
    private int divisionID;

    public Customers(int customerID, String customerName, String customerAddress, String customerPostalCode,
                     String customerPhoneNumber, int divisionID, String divisionName) {

        this.customerID = customerID;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostalCode = customerPostalCode;
        this.customerPhoneNumber = customerPhoneNumber;
        this.divisionID = divisionID;
        this.divisionName = divisionName;
    }

    public Integer getCustomerID() {

        return customerID;
    }

    public void setCustomerID(Integer customerID) {

        this.customerID = customerID;
    }

    public String getCustomerName() {

        return customerName;
    }

    public void setCustomerName(String customerName) {

        this.customerName = customerName;
    }

    public String getCustomerAddress() {

        return customerAddress;
    }

    public void setCustomerAddress(String address) {

        this.customerAddress = address;
    }

    public String getCustomerPostalCode() {

        return customerPostalCode;
    }

    public void setCustomerPostalCode(String postalCode) {

        this.customerPostalCode = postalCode;
    }

    public String getCustomerPhone() {

        return customerPhoneNumber;
    }

    public void setCustomerPhone(String phone) {

        this.customerPhoneNumber = phone;
    }

    public Integer getCustomerDivisionID() {

        return divisionID;
    }

    public String getDivisionName() {

        return divisionName;
    }

    public void setCustomerDivisionID(Integer divisionID) {

        this.divisionID = divisionID;
    }
}
