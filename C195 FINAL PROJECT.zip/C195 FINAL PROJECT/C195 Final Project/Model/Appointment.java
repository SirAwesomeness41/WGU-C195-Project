package Model;

import DAO.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDateTime;

public class Appointment {
    private int appointmentId;
    private String title;
    private String description;
    private String location;
    private String type;
    private static LocalDateTime start;
    private static LocalDateTime end;
    private int customerId;
    private int userId;
    private int contactId;
    public Appointment(int appointmentId, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, int customerId, int userId, int contactId){
        this.appointmentId = appointmentId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.customerId = customerId;
        this.userId = userId;
        this.contactId = contactId;
    }

    public int getAppointmentId(){
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId){
        this.appointmentId = appointmentId;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public String getDescription(){
        return description;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public String getLocation(){
        return location;
    }

    public void setLocation(String location){
        this.location = location;
    }

    public String getType(){
        return type;
    }

    public void setType(String type){
        this.type = type;
    }

    public static LocalDateTime getStart(){
        return start;
    }

    public void setStart(LocalDateTime start){
        this.start = start;
    }

    public static LocalDateTime getEnd(){
        return end;
    }

    public void setEnd(LocalDateTime end){
        this.end = end;
    }

    public int getCustomerId(){
        return customerId;
    }

    public void setCustomerId(int customerId){
        this.customerId = customerId;
    }

    public int getUserId(){
        return userId;
    }

    public void setUserId(int userId){
        this.userId = userId;
    }

    public int getContactId(){
        return contactId;
    }

    public void setContactId(int contactId){
        this.contactId = contactId;
    }

    public static ObservableList<Appointment> getAllAppointments(){
        ObservableList<Appointment> aList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID FROM client_schedule.appointments";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                int customerId = rs.getInt("Customer_ID");
                int userId = rs.getInt("User_ID");
                int contactId = rs.getInt("Contact_ID");

                Appointment a = new Appointment(appointmentId, title, description, location, type, start, end, customerId, userId, contactId);
                aList.add(a);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

        return aList;
    }

    public static void createAppointment(String title, String description, String location, String type, Timestamp start, Timestamp end, int customerId, int userId, int contactId){
        try{
            String sqlai = "INSERT INTO appointments VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psai = DBConnection.getConnection().prepareStatement(sqlai, Statement.RETURN_GENERATED_KEYS);
            psai.setString(1, description);
            psai.setString(2, location);
            psai.setString(3, type);
            psai.setTimestamp(4, start);
            psai.setTimestamp(5, end);
            psai.setInt(6, customerId);
            psai.setInt(7, userId);
            psai.setInt(8, contactId);
            psai.execute();

            ResultSet rs = psai.getGeneratedKeys();
            rs.next();


        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }

    public static void deleteAppointment(int appointmentId) throws SQLException {
        try{
            String sqla = "DELETE FROM appointments WHERE Appointment_ID = ?";
            PreparedStatement psa = DBConnection.getConnection().prepareStatement(sqla);
            psa.setInt(1, appointmentId);
            psa.execute();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }
}
