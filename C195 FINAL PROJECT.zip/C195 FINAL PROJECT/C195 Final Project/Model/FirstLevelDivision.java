package Model;

public class FirstLevelDivision {
    private int divisionID;
    private String divisionName;
    public int country_ID;

    public FirstLevelDivision(int divisionID, String divisionName, int country_ID) {
        this.divisionID = divisionID;
        this.divisionName = divisionName;
        this.country_ID = country_ID;
    }

    public int getDivisionID() {

        return divisionID;
    }

    public String getDivisionName() {

        return divisionName;
    }

    public int getCountry_ID() {

        return country_ID;
    }

}
