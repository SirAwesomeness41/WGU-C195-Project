package Model;

public class Contacts {
    public int contactID;
    public String contactName;
    public String contactEmail;

    public Contacts(int contactID, String contactName, String contactEmail) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    public int getId() {

        return contactID;
    }

    public String getContactName() {

        return contactName;
    }

    public String getContactEmail() {

        return contactEmail;
    }
}
