package Model;

public class ReportMonth {
    public String appointmentMonth;
    public int appointmentTotal;

    public ReportMonth(String appointmentMonth, int appointmentTotal) {
        this.appointmentMonth = appointmentMonth;
        this.appointmentTotal = appointmentTotal;
    }

    public String getAppointmentMonth() {

        return appointmentMonth;
    }

    public int getAppointmentTotal() {

        return appointmentTotal;
    }
}
