package Model;

import DAO.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class Customer {
    private int customerId;
    private String customerName;
    private String address;
    private String postalCode;
    private String phone;
    private int divisionId;
    public Customer(int customerId, String customerName, String address, String postalCode, String phone, int divisionId){
        this.customerId = customerId;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.divisionId = divisionId;
    }

    public int getCustomerId(){
        return customerId;
    }

    public void setCustomerId(int customerId){
        this.customerId = customerId;
    }

    public String getCustomerName(){
        return customerName;
    }

    public void setCustomerName(String customerName){
        this.customerName = customerName;
    }

    public String getAddress(){
        return address;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public String getPostalCode(){
        return postalCode;
    }

    public void setPostalCode(String postalCode){
        this.postalCode = postalCode;
    }

    public String getPhone(){
        return phone;
    }

    public void setPhone(String phone){
        this.phone = phone;
    }

    public int getDivisionId(){
        return divisionId;
    }

    public void setDivisionId(int divisionId){
        this.divisionId = divisionId;
    }

    public static ObservableList<Customer> getAllCustomers(){
        ObservableList<Customer> cList = FXCollections.observableArrayList();

        try{
            String sql = "SELECT Customer_ID, Customer_Name, Address, Postal_Code, Phone, Division_ID FROM client_schedule.customers";
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int customerId = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String address = rs.getString("Address");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("Phone");
                int divisionId = rs.getInt("Division_ID");

                Customer c = new Customer(customerId, customerName, address, postalCode, phone, divisionId);
                cList.add(c);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

        return cList;
    }

    public static void createCustomer(String customerName, String address, String postalCode, String phone, int divisionId){
        try{
            String sqlai = "INSERT INTO appointments VALUES(NULL, ?, ?, ?, ?, ?";
            PreparedStatement psai = DBConnection.getConnection().prepareStatement(sqlai, Statement.RETURN_GENERATED_KEYS);
            psai.setString(1, customerName);
            psai.setString(2, address);
            psai.setString(3, postalCode);
            psai.setString(4, phone);
            psai.setInt(5, divisionId);
            psai.execute();

            ResultSet rs = psai.getGeneratedKeys();
            rs.next();

        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }

    public static void deleteCustomer(int customerId) throws SQLException {
        try{
            String sqla = "DELETE FROM customers WHERE Customer_ID = ?";
            PreparedStatement psa = DBConnection.getConnection().prepareStatement(sqla);
            psa.setInt(1, customerId);
            psa.execute();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }

    }

}
