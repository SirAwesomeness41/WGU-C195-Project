import Model.Customer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class customerController {

    @FXML
    private TextField customerAddressEdit;

    @FXML
    private ComboBox<String> customerEditCountry;

    @FXML
    private TextField customerEditPhone;

    @FXML
    private TextField customerEditPostal;

    @FXML
    private ComboBox<String> customerEditState;

    @FXML
    private TextField customerIDEdit;

    @FXML
    private TextField customerNameEdit;

    @FXML
    private Button customerRecordsAddCustomer;

    @FXML
    private Button customerRecordsCancel;

    @FXML
    private Button customerRecordsEditCustomerButton;

    @FXML
    private TableView<Customer> customerRecordsTable;

    @FXML
    private TableColumn<Customer, String> customerRecordsTableAddress;

    @FXML
    private TableColumn<Customer, Integer> customerRecordsTableID;

    @FXML
    private TableColumn<Customer, String> customerRecordsTableName;

    @FXML
    private TableColumn<Customer, String> customerRecordsTablePhone;

    @FXML
    private TableColumn<Customer, String> customerRecordsTablePostalCode;

    @FXML
    private TableColumn<Customer, String> customerRecordsTableState;

    @FXML
    void customerEditCountryDropDown(ActionEvent event) {

    }

    @FXML
    void customerRecordsAddCustomer(ActionEvent event) {

    }

    @FXML
    void customerRecordsCancel(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/mainScreen.fxml"));
            Parent mainScreen = loader.load();
            Scene mainScene = new Scene(mainScreen);
            Stage winMain = (Stage)((Node)event.getSource()).getScene().getWindow();
            winMain.setTitle("Main Menu");
            winMain.setScene(mainScene);
            winMain.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }

    @FXML
    void customerRecordsDelete(ActionEvent event) {

    }

    @FXML
    void customerRecordsEditCustomerButton(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/customerUpdate.fxml"));
            Parent updateCustomer = loader.load();
            Scene upCustScene = new Scene(updateCustomer);
            Stage winCustUpdate = (Stage)((Node)event.getSource()).getScene().getWindow();
            winCustUpdate.setTitle("Customers");
            winCustUpdate.setScene(upCustScene);
            winCustUpdate.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }

    @FXML
    void customerRecordsSaveCustomer(ActionEvent event) {

    }

}
