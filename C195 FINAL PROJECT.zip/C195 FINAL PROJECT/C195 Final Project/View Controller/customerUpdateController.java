import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class customerUpdateController {

    @FXML
    private Button customerRecordsCancel;

    @FXML
    void customerRecordsCancel(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/customer.fxml"));
            Parent customer = loader.load();
            Scene custScene = new Scene(customer);
            Stage winCustomer = (Stage)((Node)event.getSource()).getScene().getWindow();
            winCustomer.setTitle("Customers");
            winCustomer.setScene(custScene);
            winCustomer.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }

}
