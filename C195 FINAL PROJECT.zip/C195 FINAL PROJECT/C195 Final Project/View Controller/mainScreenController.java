import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class mainScreenController implements Initializable{

    @FXML
    private Button mainAppointmentsButton;

    @FXML
    private Button mainCustomersButton;

    @FXML
    private Button mainExitButton;

    @FXML
    private Button mainReportsButton;

    @FXML
    private Label welcomeLabel;

    @FXML
    void appointmentsScreenOpen(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/appointments.fxml"));
            Parent a = loader.load();
            Scene as = new Scene(a);
            Stage wa = (Stage) mainAppointmentsButton.getScene().getWindow();
            wa.setTitle("Appointments");
            wa.setScene(as);
            wa.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }

    @FXML
    void closeApp(ActionEvent event) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Quit application?");
        alert.setHeaderText("Are you sure you want to quit?");
        alert.setContentText("Click ok to quit.\nClick cancel to return.");
        alert.showAndWait();
        if(alert.getResult()== ButtonType.CANCEL){
            alert.close();
        }
        else{
            Stage mainWindow = (Stage) mainExitButton.getScene().getWindow();
            mainWindow.close();
        }

    }

    @FXML
    void customersScreenOpen(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/customer.fxml"));
            Parent root = loader.load();
            Scene cs = new Scene(root);
            Stage wc = (Stage) mainCustomersButton.getScene().getWindow();
            wc.setTitle("Customers");
            wc.setScene(cs);
            wc.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }

    @FXML
    void reportsScreenOpen(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/reports.fxml"));
            Parent rep = loader.load();
            Scene reps = new Scene(rep);
            Stage wrep = (Stage) mainReportsButton.getScene().getWindow();
            wrep.setTitle("Reports");
            wrep.setScene(reps);
            wrep.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
