import DAO.DBAppointment;
import DAO.DBConnection;
import DAO.DBContacts;
import Model.Contacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import Model.Appointment;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;
import java.util.ResourceBundle;

public class appointmentsController {

    @FXML
    private Button addAppointment;

    @FXML
    private ComboBox<String> addAppointmentContact;

    @FXML
    private TextField addAppointmentCustomerID;

    @FXML
    private TextField addAppointmentDescription;

    @FXML
    private DatePicker addAppointmentEndDate;

    @FXML
    private ComboBox<Timestamp> addAppointmentEndTime;

    @FXML
    private TextField addAppointmentLocation;

    @FXML
    private DatePicker addAppointmentStartDate;

    @FXML
    private ComboBox<Timestamp> addAppointmentStartTime;

    @FXML
    private TextField addAppointmentType;

    @FXML
    private TextField addAppointmentUserID;

    @FXML
    private RadioButton allAppointmentRadio;

    @FXML
    private TableView<Appointment> allAppointmentsTable;

    @FXML
    private ToggleGroup appointment;

    @FXML
    private TableColumn<Appointment, Integer> appointmentCustomerID;

    @FXML
    private TableColumn<Appointment, String> appointmentDescription;

    @FXML
    private TableColumn<Appointment, Timestamp> appointmentEnd;

    @FXML
    private TableColumn<Appointment, Integer> appointmentID;

    @FXML
    private TableColumn<Appointment, String> appointmentLocation;

    @FXML
    private RadioButton appointmentMonthRadio;

    @FXML
    private TableColumn<Appointment, Timestamp> appointmentStart;

    @FXML
    private TableColumn<Appointment, String> appointmentTitle;

    @FXML
    private TableColumn<Appointment, String> appointmentType;

    @FXML
    private RadioButton appointmentWeekRadio;

    @FXML
    private Button backToMainMenu;

    @FXML
    private Button deleteAppointment;

    @FXML
    private Button saveAppointment;

    @FXML
    private TableColumn<Appointment, Integer> tableContactID;

    @FXML
    private TableColumn<Appointment, Integer> tableUserID;

    @FXML
    private TextField updateAppointmentID;

    @FXML
    private TextField updateAppointmentTitle;

    @FXML
    void addAppointment(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/addAppointments.fxml"));
            Parent addAppointmentsScreen = loader.load();
            Scene addAppointmentsScene = new Scene(addAppointmentsScreen);
            Stage winAddAppointment = (Stage)((Node)event.getSource()).getScene().getWindow();
            winAddAppointment.setTitle("Add Appointment");
            winAddAppointment.setScene(addAppointmentsScene);
            winAddAppointment.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }
    }

    @FXML
    void appointmentAllSelected(ActionEvent event) {
        appointmentMonthRadio.setSelected(false);
        allAppointmentRadio.setSelected(true);
        appointmentWeekRadio.setSelected(false);
        try {
            ObservableList<Appointment> allAppointmentsList = DBAppointment.getAllAppointments();

            if (allAppointmentsList != null) {
                for (Model.Appointment appointment : allAppointmentsList) {
                    allAppointmentsTable.setItems(allAppointmentsList);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
    void appointmentMonthSelected(ActionEvent event) {
        appointmentMonthRadio.setSelected(true);
        allAppointmentRadio.setSelected(false);
        appointmentWeekRadio.setSelected(false);
        try {
            ObservableList<Appointment> allAppointmentsList = DBAppointment.getAllAppointments();
            ObservableList<Appointment> appointmentsMonth = FXCollections.observableArrayList();

            LocalDateTime currentMonthStart = LocalDateTime.now().minusMonths(1);
            LocalDateTime currentMonthEnd = LocalDateTime.now().plusMonths(1);


            if (allAppointmentsList != null) {
                for (Model.Appointment appointment : allAppointmentsList){
                    if(appointment.getEnd().isAfter(currentMonthStart) && appointment.getEnd().isBefore(currentMonthEnd)){
                        appointmentsMonth.add(appointment);
                    }
                    allAppointmentsTable.setItems(appointmentsMonth);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
    void appointmentWeekSelected(ActionEvent event) {
        appointmentWeekRadio.setSelected(true);
        allAppointmentRadio.setSelected(false);
        appointmentMonthRadio.setSelected(false);

    }

    @FXML
    void backToMainMenu(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/mainScreen.fxml"));
            Parent mainScreen = loader.load();
            Scene mainScene = new Scene(mainScreen);
            Stage winMain = (Stage)((Node)event.getSource()).getScene().getWindow();
            winMain.setTitle("Main Menu");
            winMain.setScene(mainScene);
            winMain.show();
        }
        catch (IOException e) {
            System.out.println(e.getLocalizedMessage());
        }
    }

    @FXML
    void deleteAppointment(ActionEvent event) {
        try {
            Connection connection = DBConnection.getConnection();
            int deleteAppointmentID = allAppointmentsTable.getSelectionModel().getSelectedItem().getAppointmentId();
            String deleteAppointmentType = allAppointmentsTable.getSelectionModel().getSelectedItem().getType();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete the selected appointment with appointment id: " + deleteAppointmentID + " and appointment type " + deleteAppointmentType);
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                DBAppointment.deleteAppointment(deleteAppointmentID, connection);

                ObservableList<Appointment> allAppointmentsList = DBAppointment.getAllAppointments();
                allAppointmentsTable.setItems(allAppointmentsList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
    void loadAppointment(MouseEvent event) {
        try {
            DBConnection.getConnection();
            Appointment selectedAppointment = allAppointmentsTable.getSelectionModel().getSelectedItem();

            if (selectedAppointment != null) {

                ObservableList<DBContacts> contactsObservableList = DBContacts.getAllContacts();
                ObservableList<String> allContactsNames = FXCollections.observableArrayList();
                String displayContactName = "";

                for (DBContacts contact : contactsObservableList){
                    allContactsNames.add(contact.getContactName());
                }
                addAppointmentContact.setItems(allContactsNames);

                for (Contacts contact: contactsObservableList) {
                    if (selectedAppointment.getContactId() == contact.getId()) {
                        displayContactName = contact.getContactName();
                    }
                }

                updateAppointmentID.setText(String.valueOf(selectedAppointment.getAppointmentId()));
                updateAppointmentTitle.setText(selectedAppointment.getTitle());
                addAppointmentDescription.setText(selectedAppointment.getDescription());
                addAppointmentLocation.setText(selectedAppointment.getLocation());
                addAppointmentType.setText(selectedAppointment.getType());
                addAppointmentCustomerID.setText(String.valueOf(selectedAppointment.getCustomerId()));
                addAppointmentStartDate.setValue(selectedAppointment.getStart().toLocalDate());
                addAppointmentEndDate.setValue(selectedAppointment.getEnd().toLocalDate());
                addAppointmentStartTime.setValue(Timestamp.valueOf(String.valueOf(selectedAppointment.getStart().toLocalTime())));
                addAppointmentEndTime.setValue(Timestamp.valueOf(String.valueOf(selectedAppointment.getEnd().toLocalTime())));
                addAppointmentUserID.setText(String.valueOf(selectedAppointment.getUserId()));
                addAppointmentContact.setValue(displayContactName);

                ObservableList<Timestamp> appointmentTimes = FXCollections.observableArrayList();

                LocalTime firstAppointment = LocalTime.MIN.plusHours(8);
                LocalTime lastAppointment = LocalTime.MAX.minusHours(1).minusMinutes(45);

                if (!firstAppointment.equals(0) || !lastAppointment.equals(0)) {
                    while (firstAppointment.isBefore(lastAppointment)) {
                        appointmentTimes.add(Timestamp.valueOf(String.valueOf(firstAppointment)));
                        firstAppointment = firstAppointment.plusMinutes(15);
                    }
                }
                addAppointmentStartTime.setItems(appointmentTimes);
                addAppointmentEndTime.setItems(appointmentTimes);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML
    void saveAppointment(ActionEvent event) {

    }

    @Override
    public String toString(){
        return("");
    }

    public void initialize(URL location, ResourceBundle resources){
        appointmentCustomerID.setCellValueFactory(new PropertyValueFactory<>("Customer ID"));
        appointmentDescription.setCellValueFactory(new PropertyValueFactory<>("Description"));
        appointmentEnd.setCellValueFactory(new PropertyValueFactory<>("End"));
        appointmentID.setCellValueFactory(new PropertyValueFactory<>("Appointment ID"));
        appointmentLocation.setCellValueFactory(new PropertyValueFactory<>("Location"));
        appointmentStart.setCellValueFactory(new PropertyValueFactory<>("Start"));
        appointmentTitle.setCellValueFactory(new PropertyValueFactory<>("Title"));
        appointmentType.setCellValueFactory(new PropertyValueFactory<>("Type"));
        tableContactID.setCellValueFactory(new PropertyValueFactory<>("Contact ID"));
        tableUserID.setCellValueFactory(new PropertyValueFactory<>("User ID"));

        ObservableList<Appointment> appointments = Appointment.getAllAppointments();
        allAppointmentsTable.setItems(appointments);

        ToggleGroup tg = new ToggleGroup();
        appointmentMonthRadio.setToggleGroup(tg);
        allAppointmentRadio.setToggleGroup(tg);
        appointmentWeekRadio.setToggleGroup(tg);
        allAppointmentRadio.setSelected(true);

        addAppointmentContact.setVisibleRowCount(5);
        addAppointmentContact.setPromptText("Choose contact...");

        addAppointmentEndTime.setVisibleRowCount(5);
        addAppointmentEndTime.setPromptText("Choose end time...");

        addAppointmentStartTime.setVisibleRowCount(5);
        addAppointmentStartTime.setPromptText("Choose start time...");
    }

}
